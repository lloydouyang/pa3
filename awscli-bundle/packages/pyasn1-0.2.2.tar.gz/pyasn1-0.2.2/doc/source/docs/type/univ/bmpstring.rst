
BMPString type
--------------

.. autoclass:: pyasn1.type.char.BMPString(value=NoValue(), tagSet=TagSet(), subtypeSpec=ConstraintsIntersection())
   :members:
   :inherited-members:
