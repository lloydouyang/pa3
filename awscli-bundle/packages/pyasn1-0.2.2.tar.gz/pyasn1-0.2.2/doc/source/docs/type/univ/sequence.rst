
Sequence type
-------------

.. autoclass:: pyasn1.type.univ.Sequence(componentType=None, tagSet=TagSet(), subtypeSpec=ConstraintsIntersection(), sizeSpec=ConstraintsIntersection())
   :members:
   :inherited-members:
