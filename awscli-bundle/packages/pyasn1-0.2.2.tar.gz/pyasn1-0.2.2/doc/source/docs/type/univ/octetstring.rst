
OctetString type
----------------

.. autoclass:: pyasn1.type.univ.OctetString(value=NoValue(), tagSet=TagSet(), subtypeSpec=ConstraintsIntersection(), encoding='us-ascii', binValue=NoValue(), hexValue=NoValue())
   :members:
   :inherited-members:
