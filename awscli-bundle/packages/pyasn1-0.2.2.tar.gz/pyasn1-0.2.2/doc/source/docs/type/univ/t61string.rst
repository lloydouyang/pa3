
T61String type
--------------

.. autoclass:: pyasn1.type.char.T61String(value=NoValue(), tagSet=TagSet(), subtypeSpec=ConstraintsIntersection())
   :members:
   :inherited-members:
