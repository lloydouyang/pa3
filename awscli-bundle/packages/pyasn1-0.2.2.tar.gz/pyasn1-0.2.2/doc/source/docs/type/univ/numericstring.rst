
NumericString type
------------------

.. autoclass:: pyasn1.type.char.NumericString(value=NoValue(), tagSet=TagSet(), subtypeSpec=ConstraintsIntersection())
   :members:
   :inherited-members:
