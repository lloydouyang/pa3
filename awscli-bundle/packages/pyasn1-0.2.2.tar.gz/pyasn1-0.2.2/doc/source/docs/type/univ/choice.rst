
Choice type
-----------

.. autoclass:: pyasn1.type.univ.Choice(componentType=None, tagSet=TagSet(), subtypeSpec=ConstraintsIntersection(), sizeSpec=ConstraintsIntersection())
   :members:
   :inherited-members:
