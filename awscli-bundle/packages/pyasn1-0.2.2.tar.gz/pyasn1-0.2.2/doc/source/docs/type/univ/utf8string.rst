
UTF8String type
---------------

.. autoclass:: pyasn1.type.char.UTF8String(value=NoValue(), tagSet=TagSet(), subtypeSpec=ConstraintsIntersection())
   :members:
   :inherited-members:
