
Null type
---------

.. autoclass:: pyasn1.type.univ.Null(value=NoValue(), tagSet=TagSet())
   :members:
   :inherited-members:
