
Any type
--------

.. autoclass:: pyasn1.type.univ.Any(value=NoValue(), tagSet=TagSet(), subtypeSpec=ConstraintsIntersection(), encoding='us-ascii', binValue=NoValue(), hexValue=NoValue())
   :members:
   :inherited-members:
