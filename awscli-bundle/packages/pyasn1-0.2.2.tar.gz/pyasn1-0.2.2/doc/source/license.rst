.. _license:

License
=======

.. include:: ../../LICENSE.rst
